class h():
	def a(self):
		print("do nothing	")
		if False:
			self.a()