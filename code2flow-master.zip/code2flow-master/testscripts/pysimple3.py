from .pysimple2 import *
#blah
def g():
	print('my name is g')
	h.a()